# PatentRadar

Explore patents and scientific publications with source links, directly in your assistant. Replies follow your language.

- [Website / Site](https://patentradar-puce.vercel.app/)
- [Install and get started / Installation](https://patentradar-puce.vercel.app/plugin)
- [Technical documentation](https://patentradar-puce.vercel.app/developers)

No PatentRadar account or personal API key is required for the six public tools: provider_status, query_source, search_patents, lookup_patent, compare_patent_features and extract_technical_profile.

## Public installation

Download the portable package from the installation page. Extract it, open a terminal in patentradar-public and run:

    codex plugin marketplace add .
    codex plugin add patent-radar@patentradar-public

Start a new task and select PatentRadar. Codex must be installed, and your workspace must allow custom plugins. This package is publicly downloadable; it is not a claim of listing or verification in the official directory.

For tools only, with Codex CLI:

    codex mcp add patentradar --url https://patentradar-puce.vercel.app/api/mcp/patents

Other Streamable HTTP MCP clients can use the same endpoint without authentication.

## Try it

“Find patents about peristaltic pumps and cite your sources.”

“Recherche des articles scientifiques sur les capteurs microfluidiques.”

“Vérifie les sources disponibles dans PatentRadar.”

## Data and limits

Calls are processed on the remote PatentRadar server. Approved search concepts are sent to external providers. Do not submit confidential material without authorization. Extraction/comparison also sends supplied text to the remote server; it is not on-device processing.

Coverage is partial, provider quotas apply, and some sources need operator credentials. Source status is not an availability guarantee. Dataset catalogues return links, not imported patents. Comparison is lexical, without a legal conclusion.

No 3D/CAD tools, private accounts or project storage are exposed by this plugin. If a source is unavailable, use another source or the website. Never invent search results.

The optional scripts/query_source.py fallback requires Python 3 and curl.
