#!/usr/bin/env python3
"""Query PatentRadar public sources; support the deployed legacy API during rollout."""
import argparse,json,subprocess,sys
BASE='https://patentradar-puce.vercel.app'
LEGACY={'datacite','hal','arxiv','zenodo','inspire','nasa','doe','wikidata','rcsb','openaire','ror','gleif','fr-company','pubchem','opencitations','epo-linked','veyip'}
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('provider');p.add_argument('query');p.add_argument('--share-query',action='store_true',help='Only after user approval of this public query')
p.add_argument('--operation',default='search',choices=['search','patent-references','citations','references','application','claims','relations','rdf'])
p.add_argument('--publication-date');p.add_argument('--page',type=int,default=1)
a=p.parse_args()
if not a.share_query:p.error('--share-query requires prior approval to send the query to PatentRadar and its selected provider')
if not 1<=len(a.query.strip())<=150 or not 1<=a.page<=10:p.error('Use 1–150 characters and page 1–10')
payload={'provider':a.provider,'query':a.query,'operation':a.operation,'page':a.page,'consent':True}
if a.publication_date:payload['publicationDate']=a.publication_date
for route in ['/api/v1/sources/query','/api/intelligence']:
 if route.endswith('intelligence') and a.provider not in LEGACY:
  print(json.dumps({'provider':a.provider,'status':'NOT_EXPOSED','error':'This source requires the new server release; use existing patent search/lookup tools when applicable.'}));sys.exit(1)
 r=subprocess.run(['curl','--silent','--show-error','--max-time','45','--write-out','\n%{http_code}',BASE+route,'-H','Content-Type: application/json','--data-binary',json.dumps(payload)],capture_output=True,text=True)
 try:body,status=r.stdout.rsplit('\n',1);status=int(status)
 except ValueError:
  print(json.dumps({'provider':a.provider,'status':'UNAVAILABLE','error':r.stderr or 'No HTTP response'}));sys.exit(1)
 if status==404 and route.endswith('sources/query'):continue
 try:result=json.loads(body)
 except ValueError:result={'status':'UNAVAILABLE','error':'Server returned a non-JSON response'}
 result['httpStatus']=status;result['apiRoute']=route
 print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if status==200 else 1)
